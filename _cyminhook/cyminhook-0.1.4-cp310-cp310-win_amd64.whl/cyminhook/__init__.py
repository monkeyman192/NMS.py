"""
Hook functions on Windows using MinHook.
"""

from ._cyminhook import *


__version__ = "0.1.4"
